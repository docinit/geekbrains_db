-- переделанный с учетом замечаний запрос к уроку 6:

-- выбираем и считаем сообщения направленные ОТ пользователей
select from_user_id, count(from_user_id) from messages
where from_user_id !=65 and from_user_id in
-- которые находятся в списке, выдаваемом вложенным запросом
(select friend_id from friendship where friend_id = 65 or user_id = 65 union
select user_id from friendship where friend_id = 65 or user_id = 65)
-- результаты группируются, сортируются - и выбирается 1
group by from_user_id order by from_user_id limit 1;


-- переделанные с использованием join запросы из задания к 6 уроку
-- 2.
-- выбираем и считаем сообщения, направленные ОТ пользователей
select from_user_id, count(from_user_id) as messages
-- просматриваем для этого таблицы messages и friendship
from messages JOIN friendship
-- объединение делаем, используя следующие условия
on friend_id = from_user_id
-- к тому же, сообщения должны быть направлены К пользователю 65,
-- а отправитель - находиться с ним в отношениях по таблице friendship (быть другом, т.е. находиться в user_id или friend_id)
and to_user_id = 65 and (friendship.user_id = 65 or friendship.friend_id = 65)
-- группируем, выводим 1 результат
group by from_user_id limit 1;


-- 3.
-- a
create view like_counter as 
select timestampdiff(year, birthday, now()) as ages, count(l.target_id) as target from profiles p
join likes l
on l.target_id = p.user_id and target_type_id = 2
group by ages order by ages limit 10;

select sum(target) as total from like_counter;
-- b
select sum(target) as total from (select timestampdiff(year, birthday, now()) as ages, count(l.target_id) as target from profiles p
join likes l
on l.target_id = p.user_id and target_type_id = 2
group by ages order by ages limit 10) as table1;


-- 4
select sex, count(l.user_id) as counts from profiles p
join likes l
on p.user_id = l.user_id
group by sex order by counts desc limit 1;

-- 5
select u.id, count(distinct m.id)+count(distinct p.id)+count(distinct l.id)+count(distinct media.id)+count(distinct f.user_id) as activity
from users u 
left join messages m on m.from_user_id=u.id 
left join posts p on p.user_id = u.id 
left join likes l on l.user_id = u.id
left join media on media.user_id = u.id
left join friendship f on f.user_id = u.id
group by u.id
order by activity limit 10;
