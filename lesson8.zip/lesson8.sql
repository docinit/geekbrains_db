use vk;

ALTER TABLE friendship
add foreign key (user_id_fk) REFERENCES friendship(user_id),
add foreign key (friend_id) REFERENCES friendship(friend_id);

ALTER TABLE friendship
ADD CONSTRAINT friendship_user_id_fk
FOREIGN KEY (user_id) REFERENCES users(id)
on delete cascade,
ADD CONSTRAINT friend_id_fk
FOREIGN KEY (friend_id) REFERENCES users(id)
on delete cascade,
add constraint friendship_status_id_fk
foreign key (status_id) references friendship_statuses(id)
on delete cascade;


Alter table messages
add constraint messages_from_user_id_fk
foreign key (from_user_id) references users(id),
add constraint messages_to_user_id_fk
foreign key (to_user_id) references users(id);


update profiles
	set photo_id = (select m.id from media m, media_types mt where m.media_type_id=mt.id and mt.name='photo' order by rand() limit 1);

alter table profiles
add constraint profiles_user_id
foreign key (user_id) references users(id)
on delete cascade,
add constraint profiles_photo_id
foreign key (photo_id) references media(id)
on delete cascade;


-- добавляем связи с id в таблице users для полей user_id  и relative_id; при удалении данных в users будут каскадно удалены
-- данные в таблице relations - не с кем будет поддерживать родственные отношения при удалении связанного user'а.
-- при удалении каких-то статусов родственных отношений можно сохранить уже имеющиеся данные (т.е. ничего не делать с ними).
alter table relation_statuses modify id int(10) UNSIGNED; -- из-за несовместимости полей изменили формат id  в таблице relation statuses

alter table relations
add constraint relations_user_id
foreign key (user_id) references users(id)
on delete cascade,
add constraint relations_relative_id
foreign key (relative_id) references users(id)
on delete cascade,
add constraint relations_relation_status_id
foreign key (relation_status_id) references relation_statuses(id);


alter table posts
add constraint post_user_id
foreign key (user_id) references users(id);


alter table communities_users
add constraint communities_users_user_id
foreign key (user_id) references users(id)
on delete cascade,
add constraint commonities_users_community_id
foreign key (community_id) references communities(id)
on delete cascade;

-- создаем внешний ключ для media_type_id; при удалении соответствующих значений лучше каждый раз решать что именно делать:
-- при каскадном удалении пропадет много данных (нежелательно), при установлке NULL файлы, возможно, не будут корректно открываться
-- или отображаться в интерфейсе. Эта чувствительная часть, веротяно, требует индивидуального подхода каждый раз; при этом удаление
-- определенных типов файлов -  не такая частая операция.
alter table media
add constraint media_media_type_id
foreign key (media_type_id) references media_types(id);


-- при удалении в таблице users можно сохранить значения в likes; другие подходы (подставить специальное значение (-1 или др), удалить запись полностью)
-- не позволят сохранить информацию о накопленных лайках и отношении пользователей к информации.
alter table likes
add constraint likes_user_id
foreign key (user_id) references users(id),
add constraint likes_target_type_id
foreign key (target_type_id) references target_types(id),
add constraint likes_like_type_id
foreign key (like_type_id) references like_types(id);






